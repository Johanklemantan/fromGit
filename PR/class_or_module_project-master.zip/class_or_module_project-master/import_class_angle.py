from module_angle import angle as angle
print('\n')
print('-------------------SOAL-------------------')
print('''Asumsikan bahwa segitiga berikut adalah segitiga siku-siku pada Sudut BC.
Hitung sudut AB jika diketahui Sisi A = 8, dan Sisi B = 10.''')
print('\n')
print(angle.trigono(8,12))
print('\n')