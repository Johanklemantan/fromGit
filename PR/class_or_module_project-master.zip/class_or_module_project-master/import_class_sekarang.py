# import sekarang.py
from module_sekarang import Waktu as saiki

print(saiki.hari)
print(saiki.tanggal)
print(saiki.bulan)
print(saiki.tahun)
print(saiki.jam)
print(saiki.menit)
print(saiki.detik)