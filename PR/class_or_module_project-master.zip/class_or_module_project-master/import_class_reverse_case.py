from module_reverse_case import reversecase as rc

print(rc.reverse('AbcDeFghIjklMn'))