from module_statistik import stat as st

nl_new_new = [1,2,3,4,5,6,7,8,9,10,1]

print(st.get_mean(nl_new_new))
print(st.get_median(nl_new_new))
print(st.get_modus(nl_new_new))