from module_fibonacci import fibonacci as fbc

print(fbc.cek_fibo(3))
print(fbc.is_fibo(144))