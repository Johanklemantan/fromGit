![purwadhika logo](https://static.wixstatic.com/media/2e6af2_f69a4271c3534ae1869a7ed63e278b2b~mv2.png/v1/fill/w_246,h_39,al_c,usm_0.66_1.00_0.01/2e6af2_f69a4271c3534ae1869a7ed63e278b2b~mv2.png)

Selamat datang di Ujian Remedi Modul 1 JCDS01 Bekasi.

Silahkan mengerjakan soal-soal berikut ini

1. (__Poin 40__) Buatlah sebuah program Python yang menerima users input, untuk memfilter kata dalam daftar kata. Output harus berupa list. Catatan, gunakan built-in function dari Python bernama `filter()` untuk membantu anda melakukan filtering.

    daftar kata yang digunakan:
    ```
    list_word = ['merdeka', 'hello', 'sohib', 'kari ayam', 'pesawat', 'mobil', 'loker', 'kamar', 'saya', 'motor', 'pertamax', 'merah']
    ```

    Contoh:
    ```
    1.
    user input: 'me'
    output: ['merdeka', 'merah]

    2.
    user input: 'mar'
    output: ['kamar']

    3.
    user input: 'ya'
    output: ['kari ayam', 'saya']

    4.
    user input: 'te'
    output [] 
    ```

2. (__Poin 60__) Tahun kabisat (berdasarkan kalendar Gregorian) merupakan tahun yang mengalami penambahan satu hari dengan tujuan untuk menyesuaikan penanggalan dengan tahun astronomi. Dalam satu tahun tidak secara persis terdiri dari 365 hari, tetapi 365 hari 5 jam 48 menit 45,1814 detik. Jika hal ini tidak dihiraukan, maka setiap empat tahun akan kekurangan hampir 1 hari. Maka untuk mengkompensasi hal ini, setiap 4 tahun sekali, diberi 1 hari ekstra: 29 Februari.

    Buatlah sebuah program Python yang dapat menerima users input berupa tahun, untuk menentukan apakah tahun tersebut kabisat atau tidak.

    Contoh:
    ```
    1.
    User input: 1600
    Output: Tahun Kabisat

    2.
    User input: 1700
    Output: Bukan Tahun Kabisat

    3.
    User input: 2000
    Output: Tahun Kabisat

    4.
    User input: 2019
    Output: Bukan Tahun Kabisat
    ```
