def switch_to_o(word):
    word.lower()
    word = word.replace('a','o')
    word = word.replace('i','o')
    word = word.replace('u','o')
    word = word.replace('e','o')
    word = word.replace('o','o')
    print(word)
    
switch_to_o('kuda')