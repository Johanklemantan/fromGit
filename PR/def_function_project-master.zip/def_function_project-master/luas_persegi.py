def luas_persegi(sisi):
    print('Luas :', sisi*sisi)
def luas_persegi_return(sisi):
    return sisi*sisi

num = int(input('Input number: '))
luas_persegi(num)
print(luas_persegi_return(num))