print('ini dibuat dari python')
