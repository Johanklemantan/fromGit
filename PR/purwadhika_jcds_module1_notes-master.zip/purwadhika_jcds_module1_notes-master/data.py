def fungsi(x):
    return x ** 2
print(fungsi(2))