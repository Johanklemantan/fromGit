num = int(input('Masukkan angka: '))
if num%2 == 0:
    print('Angka yang Anda masukkan GENAP!')
else:
    print('Angka yang Anda masukkan GANJIL!')