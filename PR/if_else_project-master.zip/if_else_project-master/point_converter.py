nilai = int(input('Input Nilai: '))
if nilai >= 82:
    print('Nilai Anda: A')
elif nilai>=72 & nilai<=81:
    print('Nilai Anda: B')
elif nilai>=62 & nilai<=71:
    print('Nilai Anda: C')
elif nilai>=52 & nilai<=61:
    print('Nilai Anda: D')
else:
    print('Nilai Anda: E')