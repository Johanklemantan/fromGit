x = [2, 4, 6, 8]
y = map(lambda a:a**2, x)
print(list(y))