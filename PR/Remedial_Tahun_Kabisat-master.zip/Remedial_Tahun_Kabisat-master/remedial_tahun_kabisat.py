def div_4(tahun):
    if tahun%4 == 0:
        print('HASIL : TAHUN KABISAT')
    else:
        print('HASIL : BUKAN TAHUN KABISAT')

div_4(int(input('Input tahun: ')))
