b = 20
a = 1
for ii in range(b-1,0,-2):
    print(' '*(b-ii), ' *'*(ii))
for i in range(a+2,b+1,2):
    print(' '*(b-i), ' *'*(i))