b = 20
for ii in range(b-1,0,-2):
    print(' '*(b-ii), ' *'*(ii))