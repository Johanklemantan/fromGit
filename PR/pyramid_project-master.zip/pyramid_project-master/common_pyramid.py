b = 20
for i in range(1,b,2):
    print(' '*(b-i), ' *'*(i))