for i in range(0,6):
    segitiga_rev=''
    for ii in range(5,i,-1):
        segitiga_rev += ' '+str(ii)+' '
    print(segitiga_rev)