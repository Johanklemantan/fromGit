# Welcome to My Triangle Project

Dalam folder ini, saya telah mengumpulkan beberapa project yang berhubungan dengan bentuk segitiga.
Contohnya adalah:
- Segitiga Siku-Siku
```
 *
 *  *
 *  *  *
 *  *  *  *
 *  *  *  *  *
```
- Segitiga Siku-Siku Terbalik
```
 *  *  *  *  *
 *  *  *  *
 *  *  *
 *  *
 *
```
- Kotlin's Logo
``` *  *  *  *  *  *  * 
 *  *  *  *  *  *
 *  *  *  *  *
 *  *  *  *
 *  *  *
 *  *
 *
 *  *
 *  *  *
 *  *  *  *
 *  *  *  *  *
 *  *  *  *  *  *
 *  *  *  *  *  *  *
```
- Segitiga Siku-Siku yang dinomori
```
 1  2  3  4  5
 1  2  3  4
 1  2  3
 1  2
 1
```
- Segitiga Siku-Siku yang dinomori (2)
```
 5
 5  4
 5  4  3
 5  4  3  2
 5  4  3  2  1
```
- Segitiga Siku-Siku yang dinomori (3)
```
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
```
- Segititga Siku-Siku yang dinomori (4)
```
 1
 1  2
 1  2  3
 1  2  3  4
 1  2  3  4  5
```
- Segitiga Siku-Siku yang dinomori (5)
```
 5  4  3  2  1
 5  4  3  2
 5  4  3
 5  4
 5
```
- Segitiga Siku-Siku yang dinomori (6)
```
5 5 5 5 5
4 4 4 4
3 3 3
2 2
1
```

Semoga menginspirasi.
Terimakasih.
