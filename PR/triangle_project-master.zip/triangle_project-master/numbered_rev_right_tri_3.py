segitiga_siku_angka_kebalik = ''
for i in range(5,0,-1):
    segitiga_siku_angka_kebalik += ((str(i)+' ')*i)
    segitiga_siku_angka_kebalik += '\n'
print(segitiga_siku_angka_kebalik)