segitiga = ''
for i in range(1,6):
    for ii in range(i, i+1):
        segitiga += ' '+str(i)+' '
        print(segitiga)