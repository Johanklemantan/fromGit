for i in range(6,0,-1):
    segitiga_rev = ''
    for ii in range(1, i):
        segitiga_rev += ' ' + str(ii) + ' '
    print(segitiga_rev)