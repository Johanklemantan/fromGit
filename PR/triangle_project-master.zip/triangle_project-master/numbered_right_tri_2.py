num_list = [1,2,3,4,5]
num_list.reverse()
segitiga = ''
for i in num_list:
    segitiga += ' '+str(i)+' '
    print(segitiga)