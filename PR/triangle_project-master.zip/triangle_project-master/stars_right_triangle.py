def segitiga_siku(x):
    star = ''
    for i in range(x):
        star += ' * '
        print(star)
        
segitiga_siku(5)