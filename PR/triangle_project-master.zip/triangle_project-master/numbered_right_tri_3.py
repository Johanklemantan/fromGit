for i in range(0,5):
    print(((str(i+1))+' ')*(i+1))